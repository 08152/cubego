const socket = io();
let scene, camera, renderer;
let player;
let bullets = [];
let players = {};
let aiShips = {};

init();
animate();

function init(){
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x87CEEB);

  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 500);
  camera.position.set(0,10,20);

  renderer = new THREE.WebGLRenderer();
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  // Licht
  const ambient = new THREE.AmbientLight(0xffffff,0.6);
  scene.add(ambient);
  const dir = new THREE.DirectionalLight(0xffffff,0.8);
  dir.position.set(10,20,10);
  scene.add(dir);

  // Meer
  const plane = new THREE.Mesh(
    new THREE.PlaneGeometry(200,200),
    new THREE.MeshPhongMaterial({color:0x1E90FF})
  );
  plane.rotation.x = -Math.PI/2;
  scene.add(plane);

  // Spieler
  const geo = new THREE.BoxGeometry(1,0.5,2);
  const mat = new THREE.MeshPhongMaterial({color:0x00ff00});
  player = new THREE.Mesh(geo,mat);
  scene.add(player);

  // Steuerung
  window.addEventListener('keydown', e => keys[e.key.toLowerCase()]=true);
  window.addEventListener('keyup', e => keys[e.key.toLowerCase()]=false);
}

const keys = {};

function movePlayer(){
  const speed = 0.2;
  if(keys['w']){ player.position.x -= Math.sin(player.rotation.y)*speed; player.position.z -= Math.cos(player.rotation.y)*speed; }
  if(keys['s']){ player.position.x += Math.sin(player.rotation.y)*speed; player.position.z += Math.cos(player.rotation.y)*speed; }
  if(keys['a']) player.rotation.y += 0.05;
  if(keys['d']) player.rotation.y -= 0.05;

  socket.emit('move', {x:player.position.x, y:player.position.y, z:player.position.z, rotation:player.rotation.y});
}

window.addEventListener('keydown', e=>{
  if(e.key===' '){
    socket.emit('shoot', {x:player.position.x, y:player.position.y, z:player.position.z, rotation:player.rotation.y});
  }
});

socket.on('state', data=>{
  players = data.players;
  aiShips = data.aiShips;

  // Entferne alte Bullets
  bullets.forEach(b=>scene.remove(b.mesh));
  bullets = [];
  data.bullets.forEach(b=>{
    const geo = new THREE.SphereGeometry(0.1);
    const mat = new THREE.MeshPhongMaterial({color:0xff0000});
    const mesh = new THREE.Mesh(geo,mat);
    mesh.position.set(b.x,b.y+0.25,b.z);
    bullets.push({mesh,rotation:b.rotation});
    scene.add(mesh);
  });
});

function animate(){
  requestAnimationFrame(animate);
  movePlayer();

  bullets.forEach(b=>{
    b.mesh.position.x -= Math.sin(b.rotation)*0.3;
    b.mesh.position.z -= Math.cos(b.rotation)*0.3;
  });

  // Spieler aktualisieren
  for(let id in players){
    if(id===socket.id) continue;
    let p = players[id];
    let mesh = scene.getObjectByName(id);
    if(!mesh){
      const geo = new THREE.BoxGeometry(1,0.5,2);
      const mat = new THREE.MeshPhongMaterial({color:0x00ffff});
      mesh = new THREE.Mesh(geo,mat);
      mesh.name = id;
      scene.add(mesh);
    }
    mesh.position.set(p.x,p.y,p.z);
    mesh.rotation.y = p.rotation;
  }

  // KI-Schiffe rendern
  for(let ai of Object.values(aiShips)){
    let mesh = scene.getObjectByName(ai.id);
    if(!mesh){
      const geo = new THREE.BoxGeometry(1,0.5,2);
      const mat = new THREE.MeshPhongMaterial({color:0xff9900});
      mesh = new THREE.Mesh(geo,mat);
      mesh.name = ai.id;
      scene.add(mesh);
    }
    mesh.position.set(ai.x,ai.y,ai.z);
    mesh.rotation.y = ai.rotation;
  }

  camera.position.x = player.position.x + Math.sin(player.rotation.y+Math.PI)*10;
  camera.position.z = player.position.z + Math.cos(player.rotation.y+Math.PI)*10;
  camera.position.y = player.position.y + 5;
  camera.lookAt(player.position);

  renderer.render(scene,camera);
}