const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

let players = {};
let bullets = [];
let aiShips = [];

// Erstelle 3 KI-Schiffe
for (let i = 0; i < 3; i++) {
  aiShips.push({ id: 'AI'+i, x: (Math.random()-0.5)*50, y:0, z: (Math.random()-0.5)*50, rotation: Math.random()*Math.PI*2 });
}

io.on('connection', (socket) => {
  console.log('Spieler verbunden:', socket.id);
  players[socket.id] = { x:0, y:0, z:0, rotation:0 };

  // Update alle Spieler sofort
  io.emit('state', { players, bullets, aiShips });

  socket.on('move', data => {
    players[socket.id] = data;
    io.emit('state', { players, bullets, aiShips });
  });

  socket.on('shoot', data => {
    bullets.push({ id: socket.id, x:data.x, y:data.y, z:data.z, rotation:data.rotation });
    io.emit('state', { players, bullets, aiShips });
  });

  socket.on('disconnect', () => {
    delete players[socket.id];
    io.emit('state', { players, bullets, aiShips });
  });
});

// Einfache KI-Bewegung & Schießen alle 0.5s
setInterval(() => {
  aiShips.forEach(ship => {
    ship.rotation += (Math.random()-0.5)*0.1;
    ship.x -= Math.sin(ship.rotation)*0.1;
    ship.z -= Math.cos(ship.rotation)*0.1;

    // KI-Schuss zufällig
    if (Math.random()<0.05){
      bullets.push({ id: ship.id, x: ship.x, y: ship.y, z: ship.z, rotation: ship.rotation });
    }
  });
  io.emit('state', { players, bullets, aiShips });
}, 500);

http.listen(3000, ()=> console.log('Server läuft auf http://localhost:3000'));